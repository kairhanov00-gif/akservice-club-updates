"""Сервер программы. Обычно запускается сам через ярлык «АКсервис Клуб»."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

# Без консольного окна (pythonw) выводить некуда — пишем в журнал
if sys.stdout is None or sys.stderr is None:
    os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
    _log_path = os.path.join(HERE, "data", "server.log")
    if os.path.exists(_log_path) and os.path.getsize(_log_path) > 5 * 1024 * 1024:
        os.replace(_log_path, _log_path + ".old")   # журнал не растёт бесконечно
    log = open(os.path.join(HERE, "data", "server.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or log
    sys.stderr = sys.stderr or log

from app import app, lan_ip, start_worker  # noqa: E402
import db  # noqa: E402

PORT = 8000


def daily_backup(keep=30):
    """При каждом запуске — копия базы за сегодня в папку backups (храним 30 последних)."""
    import datetime
    import sqlite3
    folder = os.path.join(HERE, "backups")
    os.makedirs(folder, exist_ok=True)
    target = os.path.join(folder, f"club_{datetime.date.today().isoformat()}.db")
    if os.path.exists(db.DB_PATH) and not os.path.exists(target):
        src, dst = sqlite3.connect(db.DB_PATH), sqlite3.connect(target)
        src.backup(dst)
        src.close()
        dst.close()
    files = sorted(f for f in os.listdir(folder) if f.startswith("club_"))
    for old in files[:-keep]:
        os.remove(os.path.join(folder, old))

_lock = None


def single_instance():
    """Только одна копия сервера: вторая сразу выходит (иначе уведомления уходят дважды)."""
    global _lock
    os.makedirs(os.path.join(HERE, "data"), exist_ok=True)
    _lock = open(os.path.join(HERE, "data", "server.lock"), "a+")
    try:
        if os.name == "nt":
            import msvcrt
            _lock.seek(0)
            msvcrt.locking(_lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("Программа уже запущена — вторая копия закрывается.", flush=True)
        sys.exit(0)


if __name__ == "__main__":
    single_instance()
    try:
        daily_backup()
    except Exception as e:
        print("Резервная копия не сделана:", e)
    print("=" * 60)
    print("  АКсервис Клуб запущен")
    print(f"  На этом ПК:         http://localhost:{PORT}")
    print(f"  С телефона (Wi-Fi): http://{lan_ip()}:{PORT}")
    print("=" * 60)
    start_worker()   # уведомления WhatsApp / Telegram в фоне
    import atexit
    import wagate
    atexit.register(wagate.GATE.stop)   # шлюз WhatsApp закрывается вместе с программой
    try:
        from waitress import serve
        serve(app, host="0.0.0.0", port=PORT, threads=8)
    except ImportError:
        app.run(host="0.0.0.0", port=PORT, threaded=True)
