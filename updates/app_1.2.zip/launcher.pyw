"""Ярлык «АКсервис Клуб»: запускает сервер (если ещё не запущен) и открывает окно программы.
С параметром --server только поднимает сервер — так он стартует вместе с Windows."""
import os
import socket
import subprocess
import sys
import time
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 8000
URL = f"http://localhost:{PORT}"


def server_up():
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.5):
            return True
    except OSError:
        return False


def start_server():
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pyw):
        pyw = sys.executable
    flags = 0
    if os.name == "nt":
        flags = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED | NEW_GROUP | NO_WINDOW
    subprocess.Popen([pyw, os.path.join(HERE, "run.py")], cwd=HERE,
                     creationflags=flags, close_fds=True)
    for _ in range(80):
        if server_up():
            return True
        time.sleep(0.25)
    return False


def open_window():
    # Edge в режиме приложения: отдельное окно без адресной строки, как обычная программа
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"),
                 os.environ.get("LOCALAPPDATA")):
        if not base:
            continue
        for rel in (r"Microsoft\Edge\Application\msedge.exe",
                    r"Google\Chrome\Application\chrome.exe"):
            exe = os.path.join(base, rel)
            if os.path.exists(exe):
                subprocess.Popen([exe, f"--app={URL}", "--window-size=1280,860"])
                return
    webbrowser.open(URL)


if __name__ == "__main__":
    if "--restart" in sys.argv:          # перезапуск после восстановления копии: ждём, пока старый сервер закроется
        for _ in range(120):
            if not server_up():
                break
            time.sleep(0.5)
        time.sleep(1)
        start_server()
        sys.exit(0)
    if not server_up():
        start_server()
    if "--server" not in sys.argv:
        open_window()
